# bats.vim

Extends the built in shell highlighting (sh.vim) for [Bats - Bash
Automated Testing System](https://github.com/sstephenson/bats).

## Screenshot
![image](http://farm8.staticflickr.com/7392/9107738579_3041fc002d_o.png)

## Contact
Website:  [rosstimson.com](https://rosstimson.com)
Email:    [ross@rosstimson.com](mailto:ross@rosstimson.com)
Twitter:  [@rosstimson](https://twitter.com/rosstimson)
